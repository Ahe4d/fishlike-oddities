Tips and tricks:

- In your inventory there's an armor icon on bottom right on your character. When you click it you can put cool armor pieces on slots that appear. This way you can equip cool armor over important one, just like vanity armor in terraria. If you dont want to show any armor, press top left button on new armor slots to disable armor visibility.
- If you find random door on the surface that has weird blue and black thing behind it itäs a dimensional door. That mod is pretty dangerous, because when you enter that dimensoin, it has rooms that you can explore. Some of those rooms has traps and if you die there, you might not be able to recover your stuff and even worse, you end up in limbo dimension. In there you must find water or something to return to overworld.
- Some mobs drop rare drops that you can make mob charm from. While you have a charm in inventory, that mob wont attact you even when you hit it
- right click on ladders with empty hand to move to top/bottom instantly
- instant house mod(@prefab in JEI) is very useful, it has many houses and farms, take a look at what kind of houses it can make.