![](item:scalinghealth:difficultychanger:1) 
The cursed heart will increased difficulty when used. 
![](item:scalinghealth:difficultychanger) 
The enchanted heart will decrease difficulty when used.

They increase/decrease difficulty by ten points. There is no built-in way to obtain them provided by mod, but you may find some interesting ways, like this quest.