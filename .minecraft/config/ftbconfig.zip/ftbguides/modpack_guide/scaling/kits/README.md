![](kits.png)
Bandages and medkits will restore a percentage of your maximum health when used. 

To apply one, use it (hold right-click) for 5 seconds. You will be given the "Bandaged" potion effect and a portion of your health will be restored each second, but you will move more slowly while this is in effect. The effect is removed if your health is fully restored. 
Both bandages and medkits require heart dust to craft, so they won't be very economical to make until your maximum health is higher.