§1Miner Rank
§rMiner rank will promote when the mining points has accumulated.
You can get some benefits according to your miner rank.
If your rank is Aqua Miner or better, even though you are in the water, you can mine with ease.

§1Mining Combo
§rMining combo will accumulate when continuously mining.

If your combo accumulated, you will get some combo bonus.

§1Critical Mining
§rWhen you mined an ore, it may be happen.
In that case, it is a very good mining, and you will get more drops than the usual.

§1Mining Assist
§rMining assist will unlock when your miner rank becomes iron or higher.
In each mode, you can mine quickly.

You can switch your assist mode on press V key by default.