This mod adds living weapons, tools, and armor through the use of a new enchantment, Living! Living lets your equipment grow stronger over time, and even have their own personalities!

 Each level increases the damage and effectiveness of the weapon by a set amount, about 3% by default. For armor, the level of all pieces worn is added up, then the damage is divided by 1 + (0.032 * combined level).

So how do you obtain the enchantment in survival? By default, you can get the enchantment book or a unique enchanted item from fishing (1 in 1000 default) or from any spawned chest (1 in 9 default). Villagers should also be able to sell them.

 Enchantments also come with a personality. Each living item will respond to certain events in a way you might expect a person with that personality to respond!