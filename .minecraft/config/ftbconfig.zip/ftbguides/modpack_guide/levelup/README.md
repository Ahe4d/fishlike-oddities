Level Up! is a class and skills system for Minecraft. It allows you to choose one of three specializations, which determines what gives you bonus XP, mining, crafting, and combat. After you choose your specialization, you can open up the skill menu to see the three different skill trees.

(You can visit the Level Up! GUI at any time (L key by default) the moment you are able to choose a class.)

Choose your play style and allocate points to enhance your Minecraft experience!